<?php
/**
 * Licensed under the Open Software License version 3.0
 * See included LICENSE file for details.
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::THEME, 'frontend/chrisnanninga/luma-icons', __DIR__);
